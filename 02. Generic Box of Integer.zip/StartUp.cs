﻿using System;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Box<string> newB = new Box<string>();
            int num = int.Parse(Console.ReadLine());

            for (int i = 0; i < num; i++)
            {
                string input = Console.ReadLine();
                newB.Add(input);
               
                
            }
            Console.WriteLine(newB.ToString());


        }
    }
}
