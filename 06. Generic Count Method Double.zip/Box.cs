﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Box<T>
       where T : IComparable
    {
        private List<T> list;

        public Box()
        {
            list = new List<T>();
        }

       public void Add(T item)
        {
            list.Add(item);
        }

        public double IsDoubleComparable (T doitem)
        {
            int counter = 0;

            foreach (var iittem in list)
            {
                if (iittem.CompareTo(doitem) > 0)
                {
                    counter++;
                }
            }

            return counter;
        }

    }

}
       





