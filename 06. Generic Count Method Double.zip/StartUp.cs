﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Box<double> doubleBox = new Box<double>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                double num = double.Parse(Console.ReadLine());
                doubleBox.Add(num);
            }

            double compDoub = double.Parse(Console.ReadLine());

            double result = doubleBox.IsDoubleComparable(compDoub);
            Console.WriteLine(result);
        }
    }
}
