﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Box<int> newB = new Box<int>();

            int num = int.Parse(Console.ReadLine());

            for (int i = 0; i < num; i++)
            {
                int input = int.Parse(Console.ReadLine());
                newB.Add(input);


            }
            int[] command = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
           
            newB.Swap(command[0], command[1]);

            Console.WriteLine(newB);


        }
    }
}
