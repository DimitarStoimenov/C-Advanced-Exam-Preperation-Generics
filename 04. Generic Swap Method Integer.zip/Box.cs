﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Box<T>
    {
        private List<T> list;
       

        public Box()
        {
            this.list = new List<T>();
        }

        public void Add(T item)
        {
            list.Add(item);
        }

        public void Swap(int first, int second)
        {

            T firstElement = list[first];
            list[first] = list[second];
            list[second] = firstElement;
          
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in list)
            {
                sb.AppendLine($"System.Int32: {item}");
            }
            return sb.ToString();
        }


    }

}
       





