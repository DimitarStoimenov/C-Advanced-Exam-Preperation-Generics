﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Box<string> newB = new Box<string>();

            int num = int.Parse(Console.ReadLine());

            for (int i = 0; i < num; i++)
            {
                string input = Console.ReadLine();
                newB.Add(input);


            }
            int[] command = Console.ReadLine().Split(" ").Select(int.Parse).ToArray();
           
            newB.Swap(command[0], command[1]);

            Console.WriteLine(newB);


        }
    }
}
