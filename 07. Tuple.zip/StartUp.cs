﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            string[] nameTownInput = Console.ReadLine().Split();
            string name = $"{nameTownInput[0]} {nameTownInput[1]}";
            string town = nameTownInput[2];
            string[] nameBierInput = Console.ReadLine().Split();
            string[] numbersInput = Console.ReadLine().Split();
            
            MyTuple<string, string> nameTown = new MyTuple<string, string>(name, town);
           
            MyTuple<string, int> nameBier = new MyTuple<string, int>($"{nameBierInput[0]}", int.Parse(nameBierInput[1]));
            MyTuple<int, double> intDouble = new MyTuple<int, double>(int.Parse(numbersInput[0]), double.Parse(numbersInput[1]));

            Console.WriteLine(nameTown.GetTipe());
            Console.WriteLine(nameBier.GetTipe());
            Console.WriteLine(intDouble.GetTipe());

        }
    }
}
