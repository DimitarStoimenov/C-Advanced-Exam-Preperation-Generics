﻿using System;
using System.Linq;

namespace Generics
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Box<string> str = new Box<string>();

            int num = int.Parse(Console.ReadLine());

            for (int i = 0; i < num; i++)
            {
                string curr = Console.ReadLine();
                str.Add(curr);
            }

            string compar = Console.ReadLine();
            int result = str.IsComparable(compar);
            Console.WriteLine(result);
        }
    }
}
