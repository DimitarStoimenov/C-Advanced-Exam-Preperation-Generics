﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
    public class Box<T>
        where T : IComparable
    { 
        private List<T> list;

        public Box()
        {
            list = new List<T>();
        }

        public void Add(T item)
        {
            list.Add(item);
        }

        public int IsComparable(T element)
        {
            int count = 0;
            foreach (var it in list)
            {
                if (it.CompareTo(element) > 0)
                {
                    count++;
                }
            }

            return count;
        }




    }

}
       





